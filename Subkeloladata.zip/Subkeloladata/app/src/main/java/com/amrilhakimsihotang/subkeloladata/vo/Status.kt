package com.amrilhakimsihotang.subkeloladata.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}