package com.amrilhakimsihotang.subkeloladata.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}