package com.amrilhakimsihotang.subkeloladata.data.source.remote.response


class TiviResponse(
        val id: String,
        val originalName: String,
        val posterPath: String,
        val overview: String,
        val creatorcast: String,
        val seriescast: String,
        val writingcast: String
)